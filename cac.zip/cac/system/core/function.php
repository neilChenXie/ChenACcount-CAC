<?php
	function deal_input($data){
		$data=trim($data);
		$data=stripslashes($data);
		$data=htmlspecialchars($data);
		return $data;
	}
	function test_email($data){
		$mailpattern='"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$"';
		if(preg_match($mailpattern,$data)){
			return true;
		}else{
			return false;
		}
	}
	function test_phone($data){
		$phonepattern='/[0-9]{3}-[0-9]{7}/';
		if(preg_match($phonepattern,$data)){
			return true;
		}else{
			return false;
		}
	}
?>
<?php
	function getprodname($id,$con) {
		$prodsql='select * from Product where PID='.$id;
		if(!$prodres=mysql_query($prodsql,$con)){
			die('Cannot get info'.mysql_error());
		}
		$prodrow=mysql_fetch_array($prodres);
		if($prodrow['Name']){
			return $prodrow['Name'];
		}else{
			return false;
		}
	}
	function getprod($id,$con) {
		$prodsql='select * from Product where PID='.$id;
		if(!$prodres=mysql_query($prodsql,$con)){
			die('Cannot get info'.mysql_error());
		}
		$prodrow=mysql_fetch_array($prodres);
		if($prodrow){
			return $prodrow;
		}else{
			return false;
		}
	}
	function getspec($id,$con){
	/*get date today*/
		$alldate=getdate($timestamp=time());
		$month=$alldate['mon'];
		$year=$alldate['year'];
		$day=$alldate['mday'];
		$date=$year.'-'.$month.'-'.$day;
		//echo $date;
		$salesql="select * from Special WHERE Productid=$id AND Startdate<'$date' AND Enddate >'$date'";
		if(!$saleres=mysql_query($salesql,$con)){
			die('Cannot get info'.mysql_error());		
		}
		if($salerow=mysql_fetch_array($saleres)){
			return $salerow;
		}else{
			return false;
		}
	}
	function getcate($id,$con){
		$catesql='select * from Category where PID='.$id;
		if(!$cateres=mysql_query($catesql,$con)){
			die('Cannot get info'.mysql_error());
		}
		if($caterow=mysql_fetch_array($cateres)){
			return $caterow;
		}else{
			return false;
		}
	}
	function getcus($id,$con){
		$cussql='select * from Customer where ID='.$id;
		echo $cusssql;
		if(!$cusres=mysql_query($cussql,$con)){
			die('Cannot get info'.mysql_error());
		}
		if($cusrow=mysql_fetch_array($cusres)){
			return $cusrow;
		}else{
			return false;
		}
	}
	function getord($id,$con){
		$ordsql='select * from Myorder where ID='.$id;
		if(!$ordres=mysql_query($ordsql,$con)){
			die('Cannot get order info'.mysql_error());
		}
		if($ordrow=mysql_fetch_array($ordres)){
			return $ordrow;
		}else{
			return false;
		}

	}
	function getday(){
		$alldate=getdate($timestamp=time());
		$month=$alldate['mon'];
		$year=$alldate['year'];
		$day=$alldate['mday'];
		return $date=$year.'-'.$month.'-'.$day;
		
	}
?>

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2014, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter Application Controller Class
 *
 * This class object is the super class that every library in
 * CodeIgniter will be assigned to.
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Libraries
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/general/controllers.html
 */
class CI_Controller {

	private static $instance;

	/**
	 * Constructor
	 */
	public function __construct()
	{
		self::$instance =& $this;

		// Assign all the class objects that were instantiated by the
		// bootstrap file (CodeIgniter.php) to local class variables
		// so that CI can run as one big super object.
		foreach (is_loaded() as $var => $class)
		{
			$this->$var =& load_class($class);
		}

		$this->load =& load_class('Loader', 'core');

		$this->load->initialize();
		
		log_message('debug', "Controller Class Initialized");
	}

	public static function &get_instance()
	{
		return self::$instance;
	}
	public function deal_input($data){
		$data=trim($data);
		$data=stripslashes($data);
		$data=htmlspecialchars($data);
		return $data;
	}
	public function test_email($data){
		$mailpattern='"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$"';
		if(preg_match($mailpattern,$data)){
			return true;
		}else{
			return false;
		}
	}
	public function test_phone($data){
		$phonepattern = '/[0-9]{10,11}/';
		if(preg_match($phonepattern,$data)){
			return true;
		}else{
			return false;
		}
	}
	public function test_allaph($data) {
		$allaph = '/^[a-zA-Z]$/';
		if (preg_match($allaph,$data)) {
			return true;
		} else {
			return false;
		}
	}
	public function getday($timestamp) {
		$dateary = getdate($timestamp);
		$date = $dateary['year'].'-'.$dateary['mon'].'-'.$dateary['mday'].' '.$dateary['hours'].':'.$dateary['minutes'].':'.$dateary['seconds'];
		return $date;
	}
}
// END Controller class

/* End of file Controller.php */
/* Location: ./system/core/Controller.php */

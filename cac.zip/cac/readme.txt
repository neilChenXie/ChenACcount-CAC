controller:
	Login/signup
	Create a new account/record a new bill
	Balance the account & send information
Database design:
	User:
		uid
		name
		email
		pass
		phone
	Account:
		overall:
			aid
			uid
			pass
			kind
			date
			balanced
		member list:
			aid 
			uid

		bill overall:
			bid
			date
			cost
			description
			split method
			
		bill mem list:
			bid
			uid
		balance:
			bid
			uid
			balance

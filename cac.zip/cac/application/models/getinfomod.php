<?php
class Getinfomod extends CI_Model {
	public function getuserbyemail ($email) {
		$this->db->where('Email', $email);
		$query = $this->db->get('User');
		return $query->row();	
	}
	public function getuserbyuid ($uid) {
		$this->db->where('UID', $uid);
		$query = $this->db->get('User');
		return $query->row();
	}
	public function getaccbyaid($aid) {
		$this->db->where('AID', $aid);
		$query = $this->db->get('Account');
		return $query->row();
	}
	public function getbillbyaid($aid) {
		$this->db->where('AID', $aid);
		$this->db->order_by('Date', 'desc');
		$query = $this->db->get('Bill');
		return $query->result();
	}
	public function getaccbyuid ($uid) {
		$this->db->where('UID', $uid);
		$this->db->order_by('AID', 'desc');
		$query = $this->db->get('Memberlist');
		return $query->result();
	}
	public function getmembyaid ($aid) {
		$this->db->where('AID', $aid);
		$query = $this->db->get('Memberlist');
		$uidobj = $query->result();
		foreach($uidobj as $key => $value) {
			$uid[$key] = $value->UID;
		}
		$this->db->where_in('UID',$uid);
		$userinfo = $this->db->get('User');
		return $userinfo->result();
	}
	public function getmembybid ($bid) {
		$this->db->where('BID', $bid);
		$query = $this->db->get('Billmemlist');
		$uidobj = $query->result();
		foreach($uidobj as $key => $value) {
			$uid[$key] = $value->UID;
		}
		$this->db->where_in('UID',$uid);
		$userinfo = $this->db->get('User');
		return $userinfo->result();
	}
	public function getallcate() {
		$query = $this->db->get('Category');	
		return $query->result();
	}
	public function getcatebycid($cid) {
		if ($cid >= 100) {
			$this->db->where('NCID', $cid);
			$query = $this->db->get('Addcategory');
		} else {
			$this->db->where('CID', $cid);
			$query = $this->db->get('Category');
		}
		return $query->row();
	}
	public function getaddcatebyaid($aid) {
		$this->db->where('AID', $aid);
		$query = $this->db->get('Addcategory');
		return $query->result();
	}
	public function getsumbyaiduid($aid, $uid) {
		$this->load->library('dealinput');
		$sql = 'select sum(Cost) from Bill where AID="'.$aid.'" AND Ownuid="'.$uid.'"';
		$res = mysql_query($sql);
		$row = mysql_fetch_array($res);
		if ($row['0']) {
			return $this->dealinput->money($row['0']);
		} else {
			return 0;
		}
	}
	public function getneedpaybyaiduid($aid, $uid) {
		/*can be optimized*/
		$retval = 0;
		$bidsql = 'select * from Bill where AID = "'.$aid.'"';
		$res = mysql_query($bidsql);
		while ($row = mysql_fetch_array($res)) {
			$bid = $row['BID'];
			/*check whether in the billmemlist*/
			$memsql = 'select * from Billmemlist where BID = "'.$bid.'" AND UID = "'.$uid.'"';
			$memres = mysql_query($memsql);
			if (mysql_fetch_array($memres)) {
				$retval = $retval + $row['Average'];
			} else {
				continue;
			}
		}
		return $retval;
	}
	public function getpaidbyaiduid($aid, $uid) {
		$this->db->where('Ownuid', $uid);
		$this->db->where('AID', $aid);
		$query = $this->db->get('Bill');
		return $query->result();
	}
	public function getjoinbyaiduid($aid, $uid) {
		$this->db->select('BID');
		$this->db->where('UID', $uid);
		$query = $this->db->get('Billmemlist');
		$bidobj = $query->result();
		foreach($bidobj as $key => $value) {
			$bid[$key] = $value->BID;
		}
		$this->db->where_in('BID', $bid);
		$this->db->where('AID', $aid);
		$query = $this->db->get('Bill');
		$bill = $query->result();
		return $bill;
	}
}
?>

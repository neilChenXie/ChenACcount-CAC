<?php
class Verifymod extends CI_Model {
	public function login($email, $pass) {
		//	$sql = 'select * from User where Email = "'.$uid.'" AND Password = "'.$pass.'"';
		//	$res = mysql_query ($sql);
		//	$row = mysql_fetch_array($res);
		$this->db->where('Email', $email);
		$this->db->where('Password', $pass);
		$query = $this->db->get('User');
		//return $row;
		if ($query->row()) {
			return true;
		} else {
			return false;
		}
	}
	public function userexist($email) {
		$this->db->where('Email', $email);
		$query = $this->db->get('User');
		if ($query->row()) {
			return true;
		} else {
			return false;
		}
	}
	public function accexist($name, $uid) {
		$this->db->where('Name', $name);
		$this->db->where('UID', $uid);
		$query = $this->db->get('Account');
		$res = $query->row();
		if($res) {
			return true;
		} else {
			return false;
		}
	}
	public function memexist($aid, $uid) {
		$this->db->where('AID',$aid);
		$this->db->where('UID',$uid);
		$query = $this->db->get('Memberlist');
		if($query->row()) {
			return true;
		} else {
			return false;
		}
	}
	public function meminacc($aid,$uid) {
		$this->db->where('AID',$aid);
		$this->db->where('UID',$uid);
		$query = $this->db->get('Memberlist');
		if($query->row()) {
			return true;
		}
		return false;
	}
	public function meminaccbill($aid,$uid) {
		$bidsql = "select BID from Bill where AID = ".$aid;
		$sql = "select * from Billmemlist where UID = ".$uid." AND BID in (".$bidsql.")";
		$query = $this->db->query($sql);
		$this->db->where('Ownuid',$uid);
		$this->db->where('AID',$aid);
		$query2 = $this->db->get('Bill');
		if($query->result() || $query2->result()) {
			return true;
		}
		return false;
	}
	public function billexist ($aid, $bid, $uid) {
		$this->db->where('BID',$bid);
		$this->db->where('AID',$aid);
		/*check Bill*/
		$query = $this->db->get('Bill');
		$billobj = $query->row();
		if (!$billobj) {
			return false;
		}
		/*check uid*/
		if ($billobj->Ownuid == $uid) {
			return true;
		}
		$this->db->where('BID',$bid);
		$query = $this->db->get('Billmemlist');
		$uidobjary = $query->result();
		foreach($uidobjary as $key => $value) {
			if ($uid == $value->UID) {
				return true;
			}
		}
		return false;
	}
}


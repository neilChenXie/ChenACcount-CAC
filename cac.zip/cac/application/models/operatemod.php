<?php
class Operatemod extends CI_Model {
	public function createacc ($name, $uid, $pass) {
	//	echo 'here';
		$this->db->trans_start();
		$date = time();
		/*insert into account table*/
		$data = array ('Name' => $name, 'UID' => $uid, 'Password' => $pass, 'Startdate' => $date);
		$this->db->insert('Account', $data);
		/*return new aid*/
		$this->db->select_max('AID');
		$newaid = $this->db->get('Account');
		$row =  $newaid->row();
		$aid = $row->AID;
		/*inser to memberlist*/
		$data2 = array ('AID' => $aid, 'UID' => $uid);
		$this->db->insert('Memberlist', $data2);
		$this->db->trans_complete();
		return $aid;
	}
	public function meminsert($aid, $uid) {
		$data = array ('AID' => $aid, 'UID' => $uid);
		$this->db->insert('Memberlist', $data);
	}
	public function newcate($newcate, $aid) {
		$data = array('Name' => $newcate, 'AID' => $aid);
		$this->db->trans_start();
		$this->db->insert('Addcategory', $data);
		/*return new NCID*/
		$this->db->select_max('NCID');
		$newNCID = $this->db->get('Addcategory');
		$row = $newNCID->row();
		$ncid = $row->NCID;
		$this->db->trans_complete();
		return $ncid;
	}
	public function record($aid, $ownid, $cost, $cate, $desc, $invole) {
		$this->db->trans_start();
		$date = time();
		$num = count($invole);
		$avg = $cost/$num;
		/*insert into Bill*/
		$data = array('AID' => $aid, 'Ownuid' => $ownid, 'Date' => $date, 'Cost' => $cost, 'Category' => $cate, 'Description' => $desc, 'Average' => $avg);
		$this->db->insert('Bill', $data);
		/*return new bid*/
		$this->db->select_max('BID');
		$newbid = $this->db->get('Bill');
		$row = $newbid->row();
		$bid = $row->BID;
		/*insert into billmemlist*/
		foreach($invole as $key => $value) {
			$data2 = array('BID' => $bid, 'UID' => $value);
			$this->db->insert('Billmemlist', $data2);
		}
		$this->db->trans_complete();
	}
	public function signup($fn, $ln, $email, $pass, $phone) {
		$data = array('Firstname' => $fn, 'Lastname' => $ln, 'Email' => $email, 'Password' => $pass, 'Phone' => $phone);
		$this->db->insert('User', $data);
	}
	public function delmem($aid,$uid) {
		$this->db->where('UID', $uid);
		$this->db->where('AID', $aid);
		$this->db->delete('Memberlist');
	}
}
?>

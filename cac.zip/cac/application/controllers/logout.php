<?php
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Logout extends CI_Controller {
		public function index() {
			$rmuid = array('uid'=>'', 'step'=>'', 'aid'=>'');
			$this->session->unset_userdata($rmuid);
			$data = array('errmsg' => '');
			$this->load->view('login', $data);
		}
	}
?>

<?php
class Detail extends CI_Controller {
	public function single() {
		$this->load->model('getinfomod');
		$this->load->helper('url');
		$uid = $this->session->userdata('uid');
		$aid = $this->session->userdata('aid');
		/*check uid*/
		if(!$uid) {
			redirect('login', 'refresh');
		}
		/***********/
		/*check aid*/
		if(!$aid) {
			redirect('selser', 'refresh');	
		}
		/***********/
		/*load head of this page*/
		$this->load->view('detail/detpre');
		/*paid*/
		$paidobjary = $this->getinfomod->getpaidbyaiduid($aid, $uid);
			/*show paid*/
		$this->load->view('detail/paidtabpre');
		foreach($paidobjary as $key => $value) {
			$data['date'] = $this->getday($value->Date); 
			$data['cost'] = $value->Cost;
			$data['avg'] = $value->Average;
			$memobjary = $this->getinfomod->getmembybid($value->BID);
				/*reset member array*/
			$memary = array();
			foreach($memobjary as $key =>$value) {
				$memary[$key] = $value->Firstname.' '.$value->Lastname;
			}
			$data['memary'] = $memary;
			/*load view*/
			$this->load->view('detail/paidtab', $data);
		}
		$this->load->view('detail/endtab');
		/*joined*/
		$joinobjary = $this->getinfomod->getjoinbyaiduid($aid, $uid);
			/*show join*/
		$this->load->view('detail/topaytabpre');
		foreach($joinobjary as $key => $value) {
			$data['cost'] = $value->Cost;
			$data['avg'] = $value->Average;
			$data['date'] = $this->getday($value->Date); 
			$ownerobj = $this->getinfomod->getuserbyuid($value->Ownuid);
			$data['owner'] = $ownerobj->Firstname.' '.$ownerobj->Lastname;
			$memobjary = $this->getinfomod->getmembybid($value->BID);
				/*reset member array*/
			$memary = array();
			foreach($memobjary as $key =>$value) {
				$memary[$key] = $value->Firstname.' '.$value->Lastname;
			}
			$data['memary'] = $memary;
			/*load view*/
			$this->load->view('detail/topaytab', $data);
		}
		$this->load->view('detail/endtab');
		/*load end of this page*/
		$this->load->view('detail/detpost');
	}
}
?>

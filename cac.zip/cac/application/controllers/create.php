<?php
class Create extends CI_Controller {
	public function index () {
		/*load related lib*/
		$this->load->model('verifymod');
		$this->load->model('operatemod');
		$this->load->helper('url');
		/*check login*/
		if(!$uid = $this->session->userdata('uid')) {
		    redirect('login', 'refresh');
		}
		/*record step*/
		if(!$this->session->userdata('step')) {
		    $this->session->set_userdata(array('step' => 'create'));
		} else {
		    /*reset step*/
		    redirect('selser', 'refresh');
		}
		/*var*/
		$data = array('errmsg' => '');
		/*get data*/
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$accn = $this->deal_input($_POST['accn']);
			$pass = $this->deal_input($_POST['accpass']);
			/*validation*/
			 /*existed*/
			if($this->verifymod->accexist($accn,$uid)) {
				/*already existed*/
				$data['errmsg'] = 'already existed';
				echo 'existed';
				/*load create page*/
			} else {
				/*insert into db*/
				$newaid = $this->operatemod->createacc($accn, $uid, $pass);
				$this->session->set_userdata(array('newaccid' => $newaid));
				/*load addmem view*/
				//$this->load->view('addmem', $data);
				redirect('selser', 'refresh');
			}
		} else {
			redirect('selser', 'refresh');
		}
	}
	public function addmem () {
		$this->load->model('verifymod');
		$this->load->model('getinfomod');
		$this->load->model('operatemod');
		$this->load->helper('url');
		$data = array('errmsg' => '', 'dup' => 0);
		/*check login*/
		if(!$uid = $this->session->userdata('uid')) {
		    redirect('login', 'refresh');
		}
		/*record step*/
		if($this->session->userdata('step') == 'create') {
		    $this->session->set_userdata(array('step' => 'addmem'));
		} else {
		    /*reset step*/
		    $this->session->set_userdata(array('step' => ''));
		    redirect('selser', 'refresh');
		}

		/*************/
		$aid = $this->session->userdata('newaccid');
		foreach ($_POST as $key => $value) {
			if (strstr($key,'mememail')) {
				$tmpemail = $this->deal_input($value);
				/*check fomat*/
				if ($this->test_email($tmpemail)){
					/*check exist*/
					if ($this->verifymod->userexist($tmpemail)) {
						/*check duplicate*/
						/*get uid*/
						$userinfo = $this->getinfomod->getuserbyemail($tmpemail);
						$uid = $userinfo->UID;
						/*check duplicate*/
						if (!$this->verifymod->memexist($aid, $uid)) {
							/*insert into member table*/
							$this->operatemod->meminsert($aid,$uid);
						} else {
							$data['dup'] = $data['dup'] + 1;
						}
					} else {
						$data['errmsg'] = 'User doesn\'t exist';
						break;
					}
				} else {
					$data['errmsg'] = 'wrong fomat';
					break;
				}
			}
		}
		if ($data['errmsg']) {
			/*reload addmem page*/
			$this->load->view('addmem', $data);
		} else {
			/*back to fistpage*/
			$this->load->view('createsuc', $data);
		}
	}
}
?>

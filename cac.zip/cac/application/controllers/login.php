<?php
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Login extends CI_Controller {
		public function index () {
			/*load all login pages*/
			$data = array ('errmsg' => '');
			$this->load->view('login',$data);
		}
		public function verify () {
			$this->load->helper('url');
			$this->load->model('verifymod');
			$this->load->model('getinfomod');
			/*get information*/
			$uemail = $this->deal_input($_POST['uid']);
			$pass = $this->deal_input($_POST['pass']);
			/*validation*/
			if($uemail && $pass) {
				if(!$this->test_email($uemail)){
					$errmsg = 'wrong email format';
				} else {
					/*connect db to verify*/
					if($this->verifymod->login($uemail,$pass)) {
						/*SUCCESS*/
						$userinfo = $this->getinfomod->getuserbyemail($uemail);
						/*set session*/
						$uid = $userinfo->UID;
						$this->session->set_userdata(array('uid' => $uid));
							 /*reditrect*/
						redirect('/selser','refresh');
						//$errmsg = array('uid'=>$uemail,'pass'=>$pass);
					} else {
						/*Invalid login*/
						$errmsg = 'Invalid login';
					}
				}	
			} else {
				$errmsg = 'Information mission';
			}
			/*redirect*/
			$data = array ('errmsg' => $errmsg);
			$this->load->view('login', $data);
		}

	}
?>

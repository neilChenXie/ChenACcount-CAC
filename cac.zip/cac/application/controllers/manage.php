<?php
class Manage extends CI_Controller {
	public function show() {
		$this->load->model('getinfomod');
		$this->load->helper('url');
		/*check login*/
		if(!$this->session->userdata('uid')) {
			redirect('login', 'refresh');
		}
		/*record step*/
		if(!$this->session->userdata('step')) {
			$this->session->set_userdata(array('step' => 'manage'));
		} else {
			/*reset step*/
			redirect('selser', 'refresh');
		}
		/**********/
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$aid = $_POST['selacc'];
			$this->session->set_userdata(array('aid' => $aid));
		}
		$aid = $this->session->userdata('aid');
		$accobj = $this->getinfomod->getaccbyaid($aid);
		foreach($accobj as $key => $value) {
			$accinfo[$key] = $value;
		}
		$userobj = $this->getinfomod->getmembyaid($aid);
		/*load begin of this page*/
		$this->load->view('manage/magpre');
		/*show account info*/
		//var_dump($accinfo);
		/*show member info*/
		$this->load->view('manage/memtabpre');
		foreach($userobj as $key => $value) {
			$data['uid'] = $value->UID;
			$data['name'] = $value->Firstname.' '.$value->Lastname;
			$data['email'] = $value->Email;
			$data['phone'] = $value->Phone;
			$this->load->view('manage/memtab', $data);
		}
		$this->load->view('manage/endtab');
		/*add member button*/
		$this->load->view('manage/addmem');
		/*end of members page*/
		$this->load->view('manage/endpage');
		/*show the bill info*/
		$this->load->view('manage/billtabpre');
		$billobj = $this->getinfomod->getbillbyaid($aid);
		foreach($billobj as $key => $value) {
			$userobj = $this->getinfomod->getuserbyuid($value->Ownuid);
			$data['bid'] = $value->BID;
			$data['owner'] = $userobj->Firstname.' '.$userobj->Lastname;
			$data['date'] = $this->getday($value->Date);
			$data['cost'] = $value->Cost;
			$data['avg'] = $value->Average;
			/*get category*/
			$cateobj = $this->getinfomod->getcatebycid($value->Category);
			$data['cate'] = $cateobj->Name;
			/*get mem*/
			$memary = array();
			$memobjary = $this->getinfomod->getmembybid($value->BID);
			foreach($memobjary as $key => $mem) {
				$memary[$key] = $mem->Firstname.' '.$mem->Lastname;
			}
			$data['memary'] = $memary;
			/*get mem list*/
			$this->load->view('manage/billtab', $data);
		}
		$this->load->view('manage/endtab');
		/*end of bill page*/
		$this->load->view('manage/endpage');
		/*load end of manage*/
		$this->load->view('manage/magpost');
	}
	public function addmem() {
		$this->load->model('verifymod');
		$this->load->model('getinfomod');
		$this->load->model('operatemod');
		$this->load->helper('url');
		/*check login*/
		if(!$this->session->userdata('uid')) {
			redirect('login', 'refresh');
		}
		/*record step*/
		if($this->session->userdata('step') == 'manage' || $this->session->userdata('step') == 'addmem') {
			$this->session->set_userdata(array('step' => 'addmem'));
		} else {
			/*reset step*/
			redirect('selser', 'refresh');
		}
		/**********/
		$data['errmsg'] = '';
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			/*get email*/
			$addemail = $this->deal_input($_POST['magaddmem']);
			/*validation*/
			/*fomat*/
			$pattern = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
			if (preg_match($pattern,$addemail)) {
				/*exist*/
				if($this->verifymod->userexist($addemail)) {
					//echo $addemail;
					$aid = $this->session->userdata('aid');
					$userobj = $this->getinfomod->getuserbyemail($addemail);
					$uid = $userobj->UID;
					if($this->verifymod->memexist($aid,$uid)) {
						$data['errmsg'] = '*user already exist';
					} else {
						/*insert*/
						$this->operatemod->meminsert($aid,$uid);
						$data['errmsg'] = '';
					}
				} else {
					$data['errmsg'] = '*user doesn\'t existed';
				}
			} else {
				$data['errmsg'] = '*wrong format';
			}
			/*reset step*/
			$this->session->set_userdata(array('step' => ''));
			/*redirect*/
			if(!$data['errmsg']) {
				redirect('manage/show', 'refresh');
			}
		}
		$this->load->view('manage/addmempage', $data);
	}
	public function delbill() {
		//var_dump($_GET);
		$this->load->helper('url');
		$this->load->library("validate");
		$this->load->model('verifymod');
		$this->load->model('operatemod');
		$bid = $this->deal_input($_GET['BID']);
		$uid = $this->session->userdata('uid');
		$aid = $this->session->userdata('aid');
		$errmsg='';
		/*check login*/
		if(!$uid) {
			redirect('login', 'refresh');
		}
		/*check aid*/
		if(!$aid) {
			redirect('selser', 'refresh');
		}
		/*validation*/
		if (!$this->validate->isnum($bid)) {
			$errmsg = 'bid not num';
		} else {
			/*check if exist*/
			if ($this->verifymod->billexist($aid,$bid,$uid)) {
				/*delete*/
				$this->operatemod->delbill($bid);
			} else {
				$errmsg = 'You cannot delete this bill';
			}
		}
		if (!$errmsg) {
			/*reset step*/
			$this->session->set_userdata(array('step' => ''));
			redirect('manage/show#bill', 'refresh');
		} else {
			echo $errmsg;
		}
	}
}
?>

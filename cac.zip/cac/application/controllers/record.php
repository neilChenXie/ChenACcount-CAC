<?php
class Record extends CI_Controller {
	public function index() {
		$this->load->model('getinfomod');
		$this->load->helper('url');
		/*check login*/
		if(!$this->session->userdata('uid')) {
		    redirect('login');
		}
		/*record step*/
		if(!$this->session->userdata('step')) {
		    $this->session->set_userdata(array('step' => 'record'));
		} else {
		    /*reset step*/
		    redirect('selser');
		}
		/**********/
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$aid = $_POST['selacc'];
			$this->session->set_userdata(array('aid' => $aid));
		}
		$aid = $this->session->userdata('aid');
		/*check aid*/
		if(!$aid) {
		    redirect('selser');
		}
		/*get member list*/
		$memobjary = $this->getinfomod->getmembyaid($aid);
		$data = array('errmsg' => '');
		foreach($memobjary as $key => $value){
			$member[$value->UID] = $value->Firstname.' '.$value->Lastname;
		}
		$data['member'] = $member;
		/*get category list*/
		$cateobjary = $this->getinfomod->getallcate();
		foreach($cateobjary as $key => $value) {
			$cate[$value->CID] = $value->Name;
		}
		$addcateobjary = $this->getinfomod->getaddcatebyaid($aid);
		$addcate = NULL;
		foreach($addcateobjary as $key => $value) {
			$addcate[$value->NCID] = $value->Name;
		}
		/*transfer cate infomation*/
		$data['cate'] = $cate;
		if ($addcate) {
			$data['addcate'] = $addcate;
		} else {
			$data['addcate'] = 'empty';
		}
		/*load page*/
		$this->load->view('record', $data);
	}
	public function finalrec() {
		$this->load->helper('url');
		$this->load->model('operatemod');
		/*check login*/
		if(!$this->session->userdata('uid')) {
		    redirect('login');
		}
		/*record step*/
		if($this->session->userdata('step') == 'record') {
		    $this->session->set_userdata(array('step' => 'billdet'));
		} else {
		    /*reset step*/
		    redirect('selser');
		}
		/*************/
		/*get & check aid*/
		if(!$aid = $this->session->userdata('aid')) {
		    redirect('selser');
		}
		/*****************/
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$whopay = $_POST['whopay'];
			$whoinv = $_POST['involved'];
			$money = $_POST['money'];
			$cate = $_POST['cate'];
			$desc = $_POST['description'];
			/*validation*/
			if ($cate == 'add') {
				$newcate = $this->deal_input($_POST['newcate']);
				$ncid = $this->operatemod->newcate($newcate, $aid);
				$this->operatemod->record($aid, $whopay, $money, $ncid, $desc, $whoinv);
			} else {
				$this->operatemod->record($aid, $whopay, $money, $cate, $desc, $whoinv);
			}
			$this->load->view('recsuc');
		} else {
			$this->load->view('recsuc');
		}
	}
}
?>

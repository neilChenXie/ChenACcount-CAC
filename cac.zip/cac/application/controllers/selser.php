<?php
	class Selser extends CI_Controller {
		public function index() {
			$this->load->model('getinfomod');
			$this->load->helper('url');
			/*verify already login*/
			if(!$uid = $this->session->userdata('uid')) {
			    /*redirect back to login*/
			    redirect('/login');
			}
			/*reset session*/
			$this->session->set_userdata(array('step' => '', 'aid' => ''));
			/**********************/
			/*get user account*/
			$accobj = $this->getinfomod->getaccbyuid($uid);
			$data = array('test' => '');
			if ($accobj) {
				foreach ($accobj as $key => $value) {
					$myaid[$key] = $value->AID;
					$accn = $this->getinfomod->getaccbyaid($value->AID);
					$myaccn[$key] = $accn->Name;
				}
			} else {
				$myaid = '';
				$myaccn ='';
			}
			$data['myaid'] = $myaid;
			$data['myaccn'] = $myaccn;
			$data['uid'] = $uid;
			$this->load->view('service',$data);
		}
	}
?>

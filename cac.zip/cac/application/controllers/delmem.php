<?php
class Delmem extends CI_Controller {
	public function index() {
		$this->load->model('verifymod');
		$this->load->model('operatemod');
		$this->load->helper('url');
		/*check login*/
		if(!$this->session->userdata('uid')) {
		    redirect('login', 'refresh');
		}
		/*record step*/
		if($this->session->userdata('step') == 'manage') {
		    $this->session->set_userdata(array('step' => 'delmem'));
		} else {
		    /*reset step*/
		    redirect('selser', 'refresh');
		}
		/**********/
		if($_SERVER['REQUEST_METHOD'] == 'GET') {
			$uid = $_GET['uid'];
			$this->session->set_userdata(array('deluid' => $uid));
		}
		$uid = $this->session->userdata('deluid');
		$aid = $this->session->userdata('aid');
		/*check aid*/
		if(!$aid) {
			redirect('selser', 'refresh');
		}
		/***************/
		/*check exist in the account*/
		$miaf = $this->verifymod->meminacc($aid,$uid);
		if (!$miaf) {
			$errmsg ='member doesn\'t exist in the account';
		}
		//echo 'uid'.$uid;
		//echo 'aid'.$aid;
		/*check bill include member*/
		$miabf = $this->verifymod->meminaccbill($aid,$uid);
		if($miabf) {
			$errmsg = 'There are related bill(s) for this member';
		}
		/*delete member*/
		/*reset step*/
		$this->session->set_userdata(array('step' => ''));
		/************/
		$data['errmsg'] = $errmsg;
		if ($miaf && !$miabf) {
			$this->operatemod->delmem($aid,$uid);
			$this->load->view('manage/delmemres',$data);
		} else {
			$this->load->helper('url');
			$this->load->view('manage/delmemres',$data);
		}
	}
}
?>

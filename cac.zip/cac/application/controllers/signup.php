<?php
class Signup extends CI_Controller {
	public function index() {
		$data = array('errmsg' => '');
		$this->load->view('signup', $data);
	}
	public function verify() {
		//var_dump($_POST);
		$this->load->model('operatemod');
		$this->load->model('verifymod');
		$fn = $this->deal_input($_POST['fname']);
		$ln = $this->deal_input($_POST['lname']);
		$email = $this->deal_input($_POST['email']);
		$pass = $this->deal_input($_POST['pass']);
		$phone = $this->deal_input($_POST['phone']);
		/*validation*/
		$errmsg = '';
		if ($fn && $ln && $email && $pass && $phone) {
			if ($this->test_phone($phone)) {
				if($this->test_email($email)) {
					if ($this->verifymod->userexist($email)) {
						$errmsg = '*User existed';
					} else {
						/*insert*/
						$phone = Null; //temporal solution
						$this->operatemod->signup($fn, $ln, $email, $pass, $phone);
					}
				} else {
					$errmsg = '*wrong email fomat';
				}
			} else {
				$errmsg = '*wrong phone fomat';
			}
		}
		if ($errmsg) {
			$data = array('errmsg' => $errmsg);
			/*back to signup*/
			$this->load->view('signup',$data);
		} else {
			/*go to finish page*/
			$this->load->view('signupsuc');
		}
	}
}
?>

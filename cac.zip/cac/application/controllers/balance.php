<?php
class Balance extends CI_Controller {
	public function index() {
		$this->load->model('getinfomod');
		$this->load->helper('url');
		$this->load->library('dealinput');
		/*check login*/
		if(!$this->session->userdata('uid')) {
			redirect('login', 'refresh');
		}
		/*************/
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$aid = $_POST['selacc'];
			$this->session->set_userdata(array('aid' => $aid));
		}
		$aid = $this->session->userdata('aid');
		/*check aid*/
		if(!$aid) {
			redirect('selser', 'refresh');
		}
		/***********/
		/*get all member*/
		//$this->load->view('balance/balpre');
		$i = 0;
		foreach($this->getinfomod->getmembyaid($aid) as $key => $value) {
			$username = $value->Firstname.' '.$value->Lastname;
			$uid = $value->UID;
			/*paid*/
			$paid = $this->getinfomod->getsumbyaiduid($aid, $uid);
			/*need to pay*/
			$needpay = $this->getinfomod->getneedpaybyaiduid($aid, $uid);
			/*load view*/
			$bal = $this->dealinput->money($paid - $needpay);
			if ($uid == $this->session->userdata('uid')) {
				$data['uid'][$i] = $uid;
			} else {
				$data['uid'][$i] ='';
			}
			$data['name'][$i] = $username;
			$data['paid'][$i] = $paid;
			$data['needpay'][$i] = $needpay;
			$data['balance'][$i] = $bal;
			//$this->load->view('balance/baltable', $data);
			$i = $i + 1;
		}
		$data['numMember'] = $i;
		//var_dump($data);
		$this->load->view('balance/balance',$data);
	}
	public function delall() {
		$this->load->model('operatemod');
		$this->load->model('getinfomod');
		/*get aid*/
		$aid = $this->session->userdata('aid');
		if (!$aid) {
			$errmsg = 'No account selected';
		}
		/*delete all*/
		$this->operatemod->deleteall($aid);
		/*get all member*/
		//$this->load->view('balance/balpre');
		$i = 0;
		foreach($this->getinfomod->getmembyaid($aid) as $key => $value) {
			$username = $value->Firstname.' '.$value->Lastname;
			$uid = $value->UID;
			/*paid*/
			$paid = $this->getinfomod->getsumbyaiduid($aid, $uid);
			/*need to pay*/
			$needpay = $this->getinfomod->getneedpaybyaiduid($aid, $uid);
			/*load view*/
			$bal = $this->dealinput->money($paid - $needpay);
			if ($uid == $this->session->userdata('uid')) {
				$data['uid'][$i] = $uid;
			} else {
				$data['uid'][$i] ='';
			}
			$data['name'][$i] = $username;
			$data['paid'][$i] = $paid;
			$data['needpay'][$i] = $needpay;
			$data['balance'][$i] = $bal;
			$i = $i + 1;
			//$this->load->view('balance/baltable', $data);
		}
		$data['numMember'] = $i;
		$this->load->view('balance/balance', $data);
		//$this->load->view('balance/balpost');
	}
}
?>

<?php
class Balance extends CI_Controller {
	public function index() {
		$this->load->model('getinfomod');
		$this->load->helper('url');
		/*check login*/
		if(!$this->session->userdata('uid')) {
			redirect('login', 'refresh');
		}
		/*************/
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$aid = $_POST['selacc'];
			$this->session->set_userdata(array('aid' => $aid));
		}
		$aid = $this->session->userdata('aid');
		/*check aid*/
		if(!$aid) {
			redirect('selser', 'refresh');
		}
		/***********/
		/*get all member*/
		$this->load->view('balance/balpre');
		foreach($this->getinfomod->getmembyaid($aid) as $key => $value) {
			$username = $value->Firstname.' '.$value->Lastname;
			$uid = $value->UID;
			/*paid*/
			$paid = $this->getinfomod->getsumbyaiduid($aid, $uid);
			/*need to pay*/
			$needpay = $this->getinfomod->getneedpaybyaiduid($aid, $uid);
			/*load view*/
			$bal = $paid - $needpay;
			if ($uid == $this->session->userdata('uid')) {
				$data['uid'] = $uid;
			} else {
				$data['uid'] ='';
			}
			$data['name'] = $username;
			$data['paid'] = $paid;
			$data['needpay'] = $needpay;
			$data['balance'] = $bal;
			$this->load->view('balance/baltable', $data);
		}
		$this->load->view('balance/balpost');
	}
}
?>

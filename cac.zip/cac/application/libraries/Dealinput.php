<?php
class Dealinput {
	public function money($data) {
		$alt = $data * 100;
		$rouoff = $data*1000;
		$ff = $rouoff%10;
		if ($alt >= 0){
			$pat = '/^\d+/';
		} else {
			$pat = '/^-\d+/';
		}
		preg_match($pat, $alt, $match);
		if ($ff >= 5) {
			$match[0] = $match[0] + 1;
		}
		$new = $match[0] / 100;
		return $new;
	}
}
?>

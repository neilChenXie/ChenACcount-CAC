<?php
class Dealinput {
	public function money($data) {
		$alt = $data * 100;
		$pat = '/\d+/';
		preg_match($pat, $alt, $match);
		$new = $match[0] / 100;
		return $new;
	}
}
?>

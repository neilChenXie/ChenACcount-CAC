<?php
//if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
class Validate {
	public function isnum($data) {
		$pat = '/^\d+$/';
		if (preg_match($pat,$data)) {
			return true;
		} else {
			return false;
		}
	}
	public function isemail($data){
		$mailpattern='"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$"';
		if(preg_match($mailpattern,$data)){
			return true;
		}else{
			return false;
		}
	}
	public function isphone($data){
		$phonepattern = '/[0-9]{10,11}/';
		if(preg_match($phonepattern,$data)){
			return true;
		}else{
			return false;
		}
	}
	public function isalpha($data) {
		$allaph = '/^[a-zA-Z]$/';
		if (preg_match($allaph,$data)) {
			return true;
		} else {
			return false;
		}
	}
}
?>

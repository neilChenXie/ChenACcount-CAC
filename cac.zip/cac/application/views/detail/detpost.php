	</div>
	<div data-role='controlgroup'>
		<a href="<?php echo base_url().'index.php/selser'?>" class='ui-btn' data-ajax='false'>Service</a>
	</div>
	<div data-role='footer'>
	</div>
</body>
</html>

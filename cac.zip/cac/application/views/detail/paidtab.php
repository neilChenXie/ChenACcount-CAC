<tr>
	<td><?php echo $date;?></td>
	<td>
	<?php 
	foreach($memary as $key => $value) {
		echo $value.', ';
	}
	?>
	</td>
	<td><?php echo $cost;?></td>
	<td><?php echo $avg;?></td>
</tr>

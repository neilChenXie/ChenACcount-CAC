<table data-role='table' class='ui-responsive'>
	<caption>Joined bill</caption>
	<thead>
		<tr>
			<th>Date</th>
			<th>Owner</th>
			<th>Cost</th>
			<th>Member</th>
			<th>Average</th>
		<tr>
	</thead>
	<tbody>

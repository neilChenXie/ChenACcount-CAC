<table data-role='table' class='ui-responsive'>
	<caption>Already paid</caption>
	<thead>
		<tr>
			<th>Date</th>
			<th>Member</th>
			<th>Cost</th>
			<th>Average</th>
		<tr>
	</thead>
	<tbody>

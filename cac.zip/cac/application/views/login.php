<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>CAC</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='/template/caccss/reltable.css' type='text/css' rel='stylesheet'>
	<script src="/extend/jquery-1.11.1.min.js" type='text/javascript'></script>
	<script type='text/javascript' src='/template/cacjs/login.js'></script>
	<link rel="stylesheet" href="/extend/jquerymobile/jquery.mobile-1.4.3.min.css" type='text/css'>
	<script src="/extend/jquerymobile/jquery.mobile-1.4.3.min.js"></script>
</head>
<?php
$this->load->helper('form');
$this->load->helper('url');
?>
<body>
<div data-role='page'>
	<div data-role='header'>
		<h3>ChenACcount</h3>
	</div>
	<div data-role='main' class='ui-content' id='logindiv'>
		<!--<form action="/cac/index.php/login/verify" method='POST' id='loginform'>-->
		<?php
			$attr = array ('id' => 'loginform', 'method' => 'post', 'data-ajax' => 'false');
			echo form_open('login/verify',$attr);
		?>
		<div class='ui-field-content'>
			<table>
				<tr>
					<td colspan='1' class='gocenter'>
						<h3>CAC</h3>
					</td>
				</tr>
				<tr>
					<td class='goleft'>Email</td>
				</tr>
				<tr>
					<td>
						<input id="account" type="text" name='uid' size='15'>
					</td>
				</tr>
				<tr>
					<td id='showerr'></td>
					
				</tr>
				<tr>
					<td class='goleft'>Password</td>
				</tr>
				<tr>
					<td>
						<input id="password" type="password" name='pass' size='15'>
					</td>
				</tr>
				<?php if ($errmsg) {?>
				<tr>
					<td class='errmsg'><?php var_dump($errmsg);?></td>
				</tr>
				<?php }?>
				<tr>
					<td colspan='1' class='gocenter'>
						<input type='submit' value='Login'>
					</td>
				</tr>
				<tr>
					<td colspan='1' class='gocenter'>
						<a href='<?php echo base_url().'index.php/signup';?>' class='ui-btn' data-ajax='false'>Signup</a>
					</td>
				</tr>
			</table>
		</div>
		</form>
	</div>
	<div data-role='footer'>
		<h4><a href="https://github.com/neilChenXie/ChenAccount-CAC">Github Source Code</a></h4>
	</div>
</div>
</body>
</html>

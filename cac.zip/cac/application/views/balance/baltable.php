<?php $this->load->helper('url');?>
<tr>
	<td><b><i><?php var_dump($name);?></i></b></td>
	<td><?php echo $paid;?></td>
	<td><?php echo $needpay;?></td>
	<td><?php echo $balance;?></td>
	<?php if ($uid) {?>
	<td><a href='<?php echo base_url().'index.php/detail/single'?>' data-ajax='false'>Detail</a></td>
	<?php } ?>
</tr>

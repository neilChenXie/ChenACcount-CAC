<?php $this->load->helper('url');?>
<tr>
	<td><?php echo $name;?></td>
	<td><?php echo $paid;?></td>
	<td><?php echo $needpay;?></td>
	<td><?php echo $balance;?></td>
	<?php if ($uid) {?>
	<td><a href='<?php echo base_url().'index.php/detail/single'?>' data-ajax='false'>Detail</a></td>
	<?php } ?>
</tr>

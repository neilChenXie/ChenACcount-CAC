	</tbody>
	</table>
	<div data-role='controlgroup'>
		<a href="<?php echo base_url().'index.php/selser'?>" class='ui-btn' data-ajax='false'>Back</a>
	</div>
	</div>
	<div data-role='footer'>
	</div>
</body>
</html>

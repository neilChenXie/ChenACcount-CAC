	</tbody>
	</table>
	<div data-role='controlgroup'>
		<a href="<?php echo base_url().'index.php/selser'?>" class='ui-btn' data-ajax='false'>Back</a>
		<a href="#interal-delall" data-rel="dialog" class="ui-btn">DeleteAll</a>
	<div data-role='footer'>
	</div>
	<div id='interal-delall' data-role='page'>
		<div data-role="content">
			<a href="<?php echo base_url().'index.php/balance/delall'?>" class='ui-btn' data-ajax='false'>Yes</a>
			<a href="<?php echo base_url().'index.php/balance'?>" class='ui-btn' data-ajax='false'>No</a>
		</div>
	</div>
</body>
</html>

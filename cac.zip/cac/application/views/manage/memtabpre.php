<div data-role='page' id='member'>
	<div data-role='header'>
		<h3>Manage</h3>
		<div data-role='navbar'>
		<ul>
			<li><a href='#choice' data-ajax='false' data-icon='arrow-l'>Back</a></li>
			<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
		</ul>
		</div>
	</div>
	<div data-role='main' class='ui-content'>
		<table data-role='table' class='ui-responsive'>
			<caption>Member list</caption>
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Phone</th>
					<th>Opt.</th>
				<tr>
			</thead>
			<tbody>

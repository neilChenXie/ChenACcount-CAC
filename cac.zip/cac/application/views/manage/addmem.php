<a href='<?php echo base_url()."index.php/manage/addmem"?>' class='ui-btn' data-ajax='false'>Add member</a>

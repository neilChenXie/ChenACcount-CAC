<tr>
	<td><i><b><?php echo $date;?></b></i></td>
	<td><?php echo $owner;?></td>
	<td><?php echo $cost;?></td>
	<td><?php echo $cate?></td>
	<td>
	<?php 
		foreach($memary as $key => $value){
		echo $value.', ';
		}
	?>
	</td>
	<td>
	<?php echo $avg;?>
	</td>
	<td><a href='<?php echo base_url().'index.php/manage/delbill?BID='.$bid;?>' data-ajax='false'>Delete</a> <a href=''>Edit</a></td>
</tr>

<div data-role='page' id='bill'>
	<div data-role='header'>
		<h3>Manage</h3>
		<div data-role='navbar'>
		<ul>
			<li><a href='#choice' data-ajax='false' data-icon='arrow-l'>Back</a></li>
			<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
		</ul>
		</div>
	</div>
	<div data-role='main' class='ui-content'>
		<table data-role='table' class='ui-responsive'>
			<caption>Bill list</caption>
			<thead>
				<tr>
					<th>Date</th>
					<th>Owner</th>
					<th>Cost</th>
					<th>Category</th>
					<th>Member</th>
					<th>Average</th>
					<th>Opt.</th>
				<tr>
			</thead>
			<tbody>

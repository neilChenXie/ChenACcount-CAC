<tr>
	<td><i><b><?php echo $name;?></b></i></td>
	<td><?php echo $email;?></td>
	<td><?php echo $phone;?></td>
	<td><a href="<?php echo base_url();?>index.php/delmem?uid=<?php echo $uid;?>" data-ajax='false'>Delete</a></td>
</tr>

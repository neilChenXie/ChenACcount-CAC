<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='/template/caccss/reltable.css' type='text/css' rel='stylesheet'>
	<script src="/extend/jquery-1.11.1.min.js" type='text/javascript'></script>
	<script type='text/javascript' src='/template/cacjs/signup.js'></script>
	<link rel="stylesheet" href="/extend/jquerymobile/jquery.mobile-1.4.3.min.css" type='text/css'>
	<script src="/extend/jquerymobile/jquery.mobile-1.4.3.min.js"></script>
</head>
<?php
$this->load->helper('form');
$this->load->helper('url');
?>
<body>
	<div>
		<div data-role="header">
			<h3>
				Create a user
			</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='<?php echo base_url()."/index.php/login"?>' data-ajax='false'>Already has one</a></li>
				</ul>
			</div>
		</div>
		<div data-role="main" class='ui-content' id='signupdiv'>
			<?php
				$attr = array('data-ajax' => 'false', 'method' => 'POST', 'id' => 'signupform');
				echo form_open('/signup/verify', $attr);
			?>
				<table>
					<tr>
						<td class='goleft'>First name:</td>
					</tr>
					<tr>
						<td><input type='text' name='fname' id='fname'></td>
					</tr>
					<tr>
						<td id='fnerr' class='errmsg'></td>
					</tr>
					<tr>
						<td class='goleft'>Last name:</td>
					</tr>
					<tr>
						<td><input type='text' name='lname' id='lname'></td>
					</tr>
					<tr>
						<td id='lnerr' class='errmsg'></td>
					</tr>
					<tr>
						<td class='goleft'>Email:</td>
					</tr>
					<tr>
						<td><input type='text' name='email' id='email'></td>
					</tr>
					<tr>
						<td id='emailerr' class='errmsg'></td>
					</tr>
					<tr>
						<td class='goleft'>Password: </td>
					</tr>
					<tr>
						<td><input type='password' name='pass' id='pass'></td>
					</tr>
					<tr>
						<td class='goleft'>Password again</td>
					</tr>
					<tr>
						<td><input type='password' name='pass2' id='pass2'></td>
					</tr>
					<tr>
						<td id='passerr' class='errmsg'></td>
					</tr>
					<tr>
						<td class='goleft'>Phone: </td>
					</tr>
					<tr>
						<td><input type='text' name='phone' id='phone'></td>
					</tr>
					<tr>
						<td id='phoneerr' class='errmsg'></td>
					</tr>
					<tr>
						<td class='errmsg'><?php echo $errmsg;?></td>
					</tr>
					<tr>
						<td><input type='submit' value='submit'></td>
					</tr>
				</table>
			</form>
		</div>
		<div data-role="footer">
		</div>
	</div>
</body>
</html>

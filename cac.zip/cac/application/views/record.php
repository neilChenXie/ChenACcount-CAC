<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='/template/caccss/reltable.css' type='text/css' rel='stylesheet'>
	<script src="/extend/jquery-1.11.1.min.js" type='text/javascript'></script>
	<script type='text/javascript' src='/template/cacjs/record.js'></script>
	<link rel="stylesheet" href="/extend/jquerymobile/jquery.mobile-1.4.3.min.css" type='text/css'>
	<script src="/extend/jquerymobile/jquery.mobile-1.4.3.min.js"></script>
</head>
<?php $this->load->helper('form');?>
<?php $this->load->helper('url');?>
<body>
<?php 
	$attr = array('data-ajax' => 'false', 'method' => 'POST', 'id' => 'recform');
	echo form_open('record/finalrec',$attr);
?>
	<div data-role='page' id='whopaid'>
		<div data-role='header'>
			<h3>Record</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
				</ul>
			</div>
		</div>
		<div data-role='main' class='ui-content'>
			<fieldset class='ui-field-contain'>
				<select name='whopay' id='whopay' data-native-menu='false'>
					<option value='' selected>--Select who paid--</option>
					<?php
					foreach($member as $uid => $name) {
						echo '<option value="'.$uid.'">'.$name.'</option>';
					}
					?>
				</select>
			</fieldset>
			<fieldset data-role='controlgroup'>
				<legend>People involed(select yourself if you involved)</legend>
				<?php
				foreach($member as $uid =>$name) {
					echo '<label for="'.$name.'">'.$name.'</label>';
					echo '<input type="checkbox" name="involved[]" class="whoinvol" id="'.$name.'" value="'.$uid.'"/>';
				}
				?>
			</fieldset>
			<div data-role='controlgroup' data-type='vertical'>
					<a href='#amount' data-ajax='false' class='ui-btn' id='litsub'>Next</a>
					<a href='<?php echo base_url().'index.php/selser';?>' data-ajax='false' class='ui-btn'>Give up</a>
			</div>
		</div>
		<div data-role='footer'>
		</div>
	</div>
	<div data-role='page' id='amount'>
		<div data-role='header'>
			<h3>Record</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='#whopaid'  data-icon='arrow-l'>Back</a></li>
					<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
				</ul>
			</div>
		</div>
		<div data-role='main' class='ui-content' id='amountdiv'>
			<table id='amounttable'>
				<div class='ui-field-contain'>
					<tr>
						<td class="goleft">Amount: </td>
					</tr>
					<tr>
						 <td><input type='text' id='money' name='money' placeholder='amount spent'></td>
					</tr>
					<tr>
						<td class="errmsg" id='monerr'></td>
					</tr>
					<tr>
						<td class="goleft">Category: </td>
					</tr>
					<tr>
						<td>
							<select id='cate' name='cate' data-native-menu='false'>
								<option value='' selected>--Select category--</option>
								<optgroup label='Original'>
								<?php
									foreach($cate as $key => $value) {
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								?>
								</optgroup>
								<optgroup label='Added'>
								<?php
								if ($addcate != 'empty') {
									foreach($addcate as $key => $value) {
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								}
								?>
								</optgroup>
								<option value='add' style='font-weight:bold'>add more</option>
							</select>
						</td>
					</tr>
					<tr>
						<td id='addcate'></td>
					</tr>
					<tr>
						<td class="errmsg" id='cateerr'></td>
					</tr>
					<tr>
						<td class="goleft">Description: </td>
					</tr>
					<tr>
						<td><textarea name='description' placeholder='Add description if needed'></textarea></td>
					</tr>
				</div>
				<div data-role='controlgroup' data-type='vertical'>
					<tr>
						<td><input type='submit' value='Submit'></td>
					</tr>
					<tr>
						<td><a href='<?php echo base_url().'index.php/selser';?>' data-ajax='false' class='ui-btn'>Give up</a></td>
					</tr>
				</div>
			</table>
		</div>
		<div data-role='footer'>
		</div>
	</div>
</form>
</body>
</html>

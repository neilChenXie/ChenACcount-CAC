<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='/template/caccss/reltable.css' type='text/css' rel='stylesheet'>
	<script src="/extend/jquery-1.11.1.min.js" type='text/javascript'></script>
	<script type='text/javascript' src='/template/cacjs/addmem.js'></script>
	<link rel="stylesheet" href="/extend/jquerymobile/jquery.mobile-1.4.3.min.css" type='text/css'>
	<script src="/extend/jquerymobile/jquery.mobile-1.4.3.min.js"></script>
</head>
<?php 
$this->load->helper('form');
?>
<body>
	<div data-role='page'>
		<div data-role='header'>
			<h3>Add members</h3>
		</div>
		<div data-role='main' class='ui-content' id='addmemdiv'>
			<?php
			$attr = array( 'data-ajax' => 'false', 'method' => 'POST', 'id' => 'addmemform');
			echo form_open('/create/addmem',$attr);
			?>
			<div class='ui-field-contain'>
				<table id='addmemform'>
					<tr>
						<td>
							<legend>Select number of members in the new account</legend>
							<select name='memnum' id='memnum'>
								<option value='0' selected>select a number</option>
							<?php for($i = 1; $i<20; $i++) {								
								echo '<option value ="'.$i.'">'.$i.'</option>';
							}?>
							</select>
						</td>
					</tr>
					<tr id='memdet'>
					</tr>
					<tr>
						<td  id='addinfo' class='errmsg'>
							<?php 
								if ($errmsg) {
									echo $errmsg;
								}
							?>
						</td>
					</tr>
					<tr>
						<td><input type='submit' class='ui-btn' value='Submit'/></td>
					</tr>
				</table>
			</div>
			</form>
		</div>
		<div data-role='footer'>
			<h3>
				End of the page
			</h3>
		</div>
	</div>
</body>
</html>

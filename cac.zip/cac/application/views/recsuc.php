<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='/template/caccss/reltable.css' type='text/css' rel='stylesheet'>
	<script src="/extend/jquery-1.11.1.min.js" type='text/javascript'></script>
	<link rel="stylesheet" href="/extend/jquerymobile/jquery.mobile-1.4.3.min.css" type='text/css'>
	<script src="/extend/jquerymobile/jquery.mobile-1.4.3.min.js"></script>
</head>
<?php $this->load->helper('url');?>
<body>
	<div data-role='page'>
		<div data-role='header'>
			<h3>
				Record succeed
			</h3>
		</div>
		<div data-role='main' class='ui-content' id='createsucdiv'>
			<table id='createsuctable'>
				<tr>
					<td>Record succeed</td>
				</tr>
				<tr>
					<td><a href='<?php echo base_url().'index.php/selser';?>' data-ajax='false' class='ui-btn'>Go back</a></td>
				</tr>
			</table>
		</div>
		<div data-role='footer'>
			<h3>
				End of page
			</h3>
		</div>
	</div>
</body>
</html>

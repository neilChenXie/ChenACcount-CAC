<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='/template/caccss/reltable.css' type='text/css' rel='stylesheet'>
	<script src="/extend/jquery-1.11.1.min.js" type='text/javascript'></script>
	<script type='text/javascript' src='/template/cacjs/service.js'></script>
	<link rel="stylesheet" href="/extend/jquerymobile/jquery.mobile-1.4.3.min.css" type='text/css'>
	<script src="/extend/jquerymobile/jquery.mobile-1.4.3.min.js"></script>
</head>
<?php $this->load->helper('url');?>
<?php $this->load->helper('form');?>
<body>
	<div data-role='page' id='choice'>
		<div data-role='header'>
			<h3>Choose one service</h3>
		</div>
		<div data-role='main' class='ui-content'>
			<div data-role='controlgroup' data-type='vertical'>
				<a href="#create" class='ui-btn'>Create new account</a>
				<a href="#manage" class='ui-btn'>Manage my account</a>
				<a href="#record" class='ui-btn'>Record one expense</a>
				<a href="#balance" class='ui-btn'>Balance & Inform</a>
			</div>
		</div>
		<div data-role='controlgroup' data-type='vertical'>
			<a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' class='ui-btn'>Logout</a>
		</div>
		<div data-role='footer'>
		</div>
	</div>
	<div data-role='page' id='create'>
		<div data-role='header'>
			<h3>
				Create new account
			</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='#choice'  data-icon='arrow-l'>Back</a></li>
					<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
				</ul>
			</div>
		</div>
		<div data-role='main' class='ui-content' id='creatediv'>
		<?php
			$attr = array('method' => 'POST', 'data-ajax' => 'false', 'id' => 'createform');
			echo form_open('create',$attr);
		?>
				<table>
					<tr>
						<td class='goleft'>Name:</td>
					</tr>
					<tr>
						<td><input id='accname' name='accn' type='text' size='20' placeholder='account name'/></td>
					</tr>
					<tr>
						<td id="uid" style='display:none'><?php echo $uid;?></td>
					</tr>
					<tr>
						<td id="cheaccn" class="goleft"></td>
					</tr>
					<tr>
						<td class='goleft'>Account password:</td>
					</tr>
					<tr>
						<td><input id='newpass' name='accpass' type='password' size='20'/></td>
					</tr>
					<tr>
						<td class='goleft'>Password again:</td>
					</tr>
					<tr>
						<td><input id='newpass2' type='password' size='20'/></td>
					</tr>
					<tr>
						<td id="chepas" class="goleft"></td>
					</tr>
					<tr>
						<td class='gocenter'><input class='ui-btn' type='submit' value='Submit'></td>
					</tr>
				</table>
			</form>
		</div>
		<div data-role='footer'>
		</div>
	</div>
	<div data-role='page' id='record'>
		<div data-role='header'>
			<h3>
				Record an expense
			</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='#choice'  data-icon='arrow-l'>Back</a></li>
					<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
				</ul>
			</div>
		</div>
		<div data-role='main' class='ui-content' id='recorddiv'>
		<?php if($myaid) {?>
			<?php
				$attr = array('data-ajax' => 'false', 'method' => 'POST', 'id' => 'recordform');
				echo form_open('record', $attr);
			?>
			<table id='recordtable'>
				<tr>
					<td>
						<fieldset class='ui-field-contain'>
							<legend>Select one account</legend>
							<select name='selacc' name='selacc' data-native-menu='false'>
								<?php
									foreach ($myaid as $key => $value) {
										echo '<option value="'.$value.'">'.$myaccn[$key].'</option>';
									}
								?>
							</select>
						</fieldset>
					</td>
				</tr>
					<tr>
						<td><input type="submit" value='Go'></td>
					</tr>
			</table>
			</form>
			<?php } else {?>
				<a href="#create" class='ui-btn'>Create new account</a>
			<?php } ?>
		</div>
		<div data-role='footer'>
		</div>
	</div>
	<div data-role='page' id='balance'>
		<div data-role='header'>
			<h3>
				Balance
			</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='#choice'  data-icon='arrow-l'>Back</a></li>
					<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
				</ul>
			</div>
		</div>
		<div data-role='main' class='ui-content' id='balancediv'>
		<?php if($myaid) {?>
			<?php
				$attr = array('data-ajax' => 'false', 'method' => 'POST', 'id' => 'balanceform');
				echo form_open('balance', $attr);
			?>
			<table>
				<tr>
					<td>
						<fieldset class='ui-field-contain'>
							<legend>Select one account</legend>
							<select name='selacc' name='selacc' data-native-menu='false'>
								<?php
									foreach ($myaid as $key => $value) {
										echo '<option value="'.$value.'">'.$myaccn[$key].'</option>';
									}
								?>
							</select>
						</fieldset>
					</td>
				</tr>
					<tr>
						<td><input type="submit" value='Go'></td>
					</tr>
			</table>
			</form>
			<?php } else {?>
				<a href="#create" class='ui-btn'>Create new account</a>
			<?php } ?>
		</div>
		<div data-role='footer'>
		</div>
	</div>
	<div data-role='page' id='manage'>
		<div data-role='header'>
			<h3>
				Manage
			</h3>
			<div data-role='navbar'>
				<ul>
					<li><a href='#choice'  data-icon='arrow-l'>Back</a></li>
					<li><a href='<?php echo base_url().'index.php/logout';?>' data-ajax='false' data-icon='home'>Logout</a></li>
				</ul>
			</div>
		</div>
		<div data-role='main' class='ui-content' id ='selaccdiv'>
		<?php if($myaid) {?>
			<?php
				$attr = array('data-ajax' => 'false', 'method' => 'POST', 'id' => 'selaccform');
				echo form_open('manage/show', $attr);
			?>
			<table id='selacctable'>
				<tr>
					<td>
						<fieldset class='ui-field-contain'>
							<legend>Select one account</legend>
							<select name='selacc' name='selacc' data-native-menu='false'>
								<?php
									foreach ($myaid as $key => $value) {
										echo '<option value="'.$value.'">'.$myaccn[$key].'</option>';
									}
								?>
							</select>
						</fieldset>
					</td>
				</tr>
					<tr>
						<td><input type="submit" value='Go'></td>
					</tr>
			</table>
			</form>
			<?php } else {?>
				<a href="#create" class='ui-btn'>Create new account</a>
			<?php } ?>
		</div>
		<div data-role='footer'>
		</div>
	</div>
</body>
</html>

